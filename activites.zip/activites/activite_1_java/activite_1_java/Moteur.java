package activite_1_java;

public abstract class Moteur {
	protected TypeMoteur type;
	protected String cylindre;
	protected double prix;
	
	public abstract void Moteur(String cylindre,double prix);
	
	public double getPrix() {
		return this.prix;
	}

	public String toString() {
		return  type.getType() + ", " + this.cylindre + ", (" + this.prix + "�)";
	}
	
}
