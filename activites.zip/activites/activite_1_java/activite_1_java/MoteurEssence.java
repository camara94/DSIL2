package activite_1_java;

public class MoteurEssence extends Moteur{

	public MoteurEssence() {}
	
	public MoteurEssence(String cylindre, double prix) {
		this.cylindre = cylindre;
		this.prix = prix;
	}
	@Override
	public void Moteur(String cylindre, double prix) {
		System.out.println(this.cylindre + " (" + this.prix + "�)" );
	}

}