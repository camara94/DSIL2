package activite_1_java;

public class MoteurElectrique extends Moteur{

	public MoteurElectrique() {}
	
	public MoteurElectrique(String cylindre, double prix) {
		this.cylindre = cylindre;
		this.prix = prix;
	}
	@Override
	public void Moteur(String cylindre, double prix) {
		System.out.println(this.cylindre + " (" + this.prix + "�)" );
	}

}