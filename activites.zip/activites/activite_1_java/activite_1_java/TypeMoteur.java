package activite_1_java;

public enum TypeMoteur {
	DUESEL("moteur DUESEL"),
	ESSENCE("moteur ESSENCE"),
	HYBRIDE("moteur HYBRIDE ESSENCE/ELECTRIQUE"),
	ELECTRIQUE("moteur ELECTRIQUE");
	
	private String type;
	
	TypeMoteur()
	{
		this.type = "";
	}
	
	private TypeMoteur(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
