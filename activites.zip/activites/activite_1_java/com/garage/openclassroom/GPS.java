package com.garage.openclassroom;

public class GPS implements Option{
	double prix;
	public GPS() {
		this.prix = 113.5;
	}

	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return  this.prix;
	}
}
