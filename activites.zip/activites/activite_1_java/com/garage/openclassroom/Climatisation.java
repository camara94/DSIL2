package com.garage.openclassroom;

public class Climatisation implements Option{
	private double prix;
	public Climatisation() {
		// TODO Auto-generated constructor stub
		this.prix = 347.3;
	}
	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return this.prix;
	}

}
