package com.garage.openclassroom;

public class BarreDeToit {
	private double prix;
	public BarreDeToit() {
		// TODO Auto-generated constructor stub
		this.prix = 
	}

}
