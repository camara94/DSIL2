package com.garage.openclassroom;

public interface Option {
	public double getPrix();
}
