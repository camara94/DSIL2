// Voici le fichier JavaScript r�f�renc� par index.html. Il est actuellement vide.
// En ajoutant du code dans ce fichier vide et en affichant index.html dans un
// navigateur, vous pouvez tester la page d'exemple ou suivre les exemples du livre.
$(document).ready(function() {
	$("#selected-plays>li").addClass("horizontal");
	$("ul>li>ul").addClass("sub-level");
	$('a[href^="mailto"]').addClass("mailto");
	$('a[href^=".pdf"]').addClass("pdflink");

 
});