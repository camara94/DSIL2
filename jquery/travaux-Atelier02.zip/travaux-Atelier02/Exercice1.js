//1
$('td:eq(0)').css('background','red');
$('td:eq(17)').css('background','red');
//2
$('td:empty').text('Moi');

//3
$('tr:even').css('background','#ccffff');
$('tr:odd').css('background','#ccff99');
//4
for (var i = 2; i < 5; i++) {
	alert($('tr:eq('+i+')').text());
}
//5
alert($('tr:eq(5)').text());
//6
alert($('tr:eq(5)').html());

 

