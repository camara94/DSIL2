<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

      $bd_url_serveur = "localhost";
      $bd_utilisateur = "isetjb";
      $bd_mot_de_passe = "isetjb";
      $bd_nom = "iset_2018_l2dsi";

      // Créer une connexion
      $cnx = new mysqli($bd_url_serveur, $bd_utilisateur, $bd_mot_de_passe, $bd_nom);
      // Vérifier la connexion
      if ($cnx->connect_error) {
        die("Problème lors de la connexion: " . $cnx->connect_error);
      }

     ?>
    <a href="personne_ajouter.php">ajouter</a>
    <br>
    <table border="1">
      <tr>
        <th>Nom</th>
        <th>Age</th>
        <th>&nbsp;</th>
      </tr>
      <?php

        // préparation et exécution de la requête
        $requette = "SELECT * FROM personne";
        //echo $requette;
        $resultat = $cnx->query($requette);

        // vérifier s'il existe des lignes
        if ($resultat->num_rows > 0) {
            // récupération et affichage des données de chaque ligne
            while($ligne = $resultat->fetch_assoc()) {
              echo "<tr>";
              echo "<td>" . $ligne["nom"] . "</td>";
              echo "<td>" . $ligne["age"] . "</td>";
              echo "<td>";
              echo "<a href='personne_modifier.php?id_p=" . $ligne["id_personne"] . "'>modifier</a> ";
              echo "<a href='personne_supprimer.php?id_p=" . $ligne["id_personne"] . "'>supprimer</a>";
              echo "</td>";
              echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3'>0 résultat</td></tr>";
        }
        $cnx->close();
       ?>
    </table>
  </body>
</html>
