<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

      $idPersonne = $_GET["id_p"];

      $bd_url_serveur = "localhost";
      $bd_utilisateur = "isetjb";
      $bd_mot_de_passe = "isetjb";
      $bd_nom = "iset_2018_l2dsi";

      // Créer une connexion
      $cnx = new mysqli($bd_url_serveur, $bd_utilisateur, $bd_mot_de_passe, $bd_nom);
      // Vérifier la connexion
      if ($cnx->connect_error) {
        die("Problème lors de la connexion: " . $cnx->connect_error);
      }


      $requette = "SELECT * FROM personne WHERE id_personne = " . $idPersonne;
      //echo $requette;

      $resultat = $cnx->query($requette);

      if ($resultat->num_rows > 0) {

          $ligne = $resultat->fetch_assoc();

          $nom = $ligne["nom"];
          $age = $ligne["age"];

      } else {
          echo "Personne inexistante !";
      }
      $cnx->close();

     ?>
    <?php
      if ($resultat->num_rows > 0)
      {
    ?>
        <h1>Modifier une personne</h1>
        <form method="get" action="personne_modifier_enregistrer.php">
          Nom : <input type="text" name="nom" value="<?php echo $nom; ?>">
          <br>
          Age : <input type="text" name="age" value="<?php echo $age; ?>">
          <br>
          <input type="hidden" name="id_p" value="<?php echo $idPersonne; ?>">
          <input type="submit" value="enregistrer">
          <br>
        </form>

    <?php
      }
     ?>

  </body>
</html>
