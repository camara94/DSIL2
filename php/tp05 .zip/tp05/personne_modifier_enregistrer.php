<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      $bd_url_serveur = "localhost";
      $bd_utilisateur = "isetjb";
      $bd_mot_de_passe = "isetjb";
      $bd_nom = "iset_2018_l2dsi";

      // Créer une connexion
      $cnx = new mysqli($bd_url_serveur, $bd_utilisateur, $bd_mot_de_passe, $bd_nom);
      // Vérifier la connexion
      if ($cnx->connect_error) {
        die("Problème lors de la connexion: " . $cnx->connect_error);
      }

      $nom = $_GET["nom"];
      $age = $_GET["age"];
      $idPersonne = $_GET["id_p"];

      // préparation et exécution de la requête
      $requette = "UPDATE personne "
        . " SET nom='" . $nom . "', age = " . $age
        . " WHERE id_personne = " . $idPersonne;
      //echo $requette;

      if ($cnx->query($requette)) {
          echo "Enregistrement réussit";
      } else {
          echo "Erreur : " . $requette . "<br>" . $cnx->error;
      }

      $cnx->close();
     ?>
     <br>
     <a href='personne_lister.php'>retour</a>
  </body>
</html>
