<?php
function se_connecter()
{
  $bd_url_serveur = "localhost";
  $bd_utilisateur = "isetjb";
  $bd_mot_de_passe = "isetjb";
  $bd_nom = "iset_2018_l2dsi";

  try {
      $cnx = new PDO("mysql:host=$bd_url_serveur;dbname=$bd_nom", $bd_utilisateur, $bd_mot_de_passe);
      // set the PDO error mode to exception
      $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      // use exec() because no results are returned
      return $cnx;
      }
  catch(PDOException $e)
      {
      echo $sql . "<br>" . $e->getMessage();
      }

  return null;
}

$cnx = se_connecter();

 ?>
