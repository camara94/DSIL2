<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "personne.php";

      $idPersonne = $_GET["id_p"];

      $ligne = recuperer_une($idPersonne);

      if (count($ligne) > 0) {

          $nom = $ligne["nom"];
          $age = $ligne["age"];

      } else {
          echo "Personne inexistante !";
      }

     ?>
    <?php
      if (count($ligne) > 0)
      {
    ?>
        <h1>Modifier une personne</h1>
        <form method="get" action="personne_modifier_enregistrer.php">
          Nom : <input type="text" name="nom" value="<?php echo $nom; ?>">
          <br>
          Age : <input type="text" name="age" value="<?php echo $age; ?>">
          <br>
          <input type="hidden" name="id_p" value="<?php echo $idPersonne; ?>">
          <input type="submit" value="enregistrer">
          <br>
        </form>

    <?php
      }
     ?>

  </body>
</html>
