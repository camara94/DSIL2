<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    require_once "connexion.php";
    function ajouter($nom,$age)
    {
      $cnx=se_connecter();
      $requette = "INSERT INTO personne(nom, age) "
        . "VALUES('" . $nom . "', " . $age . ")";
        //echo $requette;
        return $cnx->query($requette);
    }

    function modifier($idpersonne,$nom,$age)
    {
      $cnx=se_connecter();
      $requette = "UPDATE personne "
        . " SET nom='" . $nom . "', age = " . $age
        . " WHERE id_personne = " . $idpersonne;
      return $cnx->query($requette);
    }

    function select($idpersonne)
    {
      $cnx=se_connecter();
      $requette = "SELECT * FROM personne WHERE id_personne = " . $idpersonne;
      return $cnx->query($requette);
    }

    function supprimer($idpersonne)
    {
        $cnx=se_connecter();
        $requette = "DELETE FROM personne WHERE id_personne = " . $idpersonne;
        return $cnx->query($requette);
    }
    
    function lister()
    {
        $cnx=se_connecter();
        $requette = "SELECT * FROM personne";
        return $cnx->query($requette);
    }
     ?>


  </body>
</html>
