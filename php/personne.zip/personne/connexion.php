<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    function se_connecter()
    {


            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "sami_baccouche";
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Vérifier la connexion
            if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
            }
      return $conn;
    }
    ?>
  </body>
</html>
