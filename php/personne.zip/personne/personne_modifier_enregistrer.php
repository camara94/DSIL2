<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "personne.php";
      $nom = $_GET["nom"];
      $age = $_GET["age"];
      $idPersonne = $_GET["id_p"];


      //echo $requette;

      if (modifier($idPersonne,$nom,$age)) {
          echo "Enregistrement réussi";
      } else {
          echo "Erreur <br>";
      }


     ?>
     <br>
     <a href='personne_lister.php'>retour</a>
  </body>
</html>
