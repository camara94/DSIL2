<?php
	$server = 'localhost';
	$password = '';
	$login = 'root';
	$dataBase = 'filter';

	try {
		$connexion = new PDO('mysql:host=' .$server. ';', $login, $password);
		$data = "CREATE DATABASE  filtre";
		$d = $connexion->query($data);
		echo "la table filtre est créee";
	} catch (PDOException $e) {
		echo 'Erreur : ' . $e->getMessage();
	}

?>