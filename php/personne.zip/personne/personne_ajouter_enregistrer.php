<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php



      require_once "personne.php";
      $nom = $_GET["nom"];
      $age = $_GET["age"];
      //echo  $age;
      if (ajouter($nom,$age)) {
          echo "Enregistrement réussit";
      } else {
          echo "Erreur " ;
      }


     ?>
     <br>
     <a href='personne_lister.php'>retour</a>
  </body>
</html>
