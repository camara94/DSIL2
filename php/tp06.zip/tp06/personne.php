<?php

require_once "connexion.php";

function recuperer()
{
  $lignes = array();

  // se connecter à la base
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = "SELECT * FROM personne";
  //echo $requette;
  $resultat = $cnx->query($requette);

  // vérifier s'il existe des lignes
  if ($resultat->num_rows > 0) {
      // récupération et affichage des données de chaque ligne
      while($ligne = $resultat->fetch_assoc()) {
        $lignes[] = $ligne;
      }
  }

  $cnx->close();

  return $lignes;
}

function ajouter($nom, $age)
{
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = "INSERT INTO personne(nom, age) "
    . "VALUES('" . $nom . "', " . $age . ")";
  //echo $requette;

  return $cnx->query($requette);
}

function supprimer($id_personne)
{
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = "DELETE FROM personne WHERE id_personne = " . $id_personne;
  //echo $requette;

  return $cnx->query($requette);
}


function recuperer_une($id_personne)
{
  $ligne = array();

  // se connecter à la base
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = "SELECT * FROM personne WHERE id_personne = " . $id_personne;
  //echo $requette;
  $resultat = $cnx->query($requette);

  // vérifier s'il existe des lignes
  if ($resultat->num_rows > 0) {
      $ligne = $resultat->fetch_assoc();
  }

  $cnx->close();

  return $ligne;
}

function modifier($id_personne, $nom, $age)
{
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = "UPDATE personne "
    . " SET nom='" . $nom . "', age = " . $age
    . " WHERE id_personne = " . $id_personne;
  //echo $requette;

  return $cnx->query($requette);
}

?>
