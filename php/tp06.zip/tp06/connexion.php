<?php
function se_connecter()
{
  $bd_url_serveur = "localhost";
  $bd_utilisateur = "isetjb";
  $bd_mot_de_passe = "isetjb";
  $bd_nom = "iset_2018_l2dsi";

  // Créer une connexion
  $cnx = new mysqli($bd_url_serveur, $bd_utilisateur, $bd_mot_de_passe, $bd_nom);
  // Vérifier la connexion
  if ($cnx->connect_error) {
    die("Problème lors de la connexion: " . $cnx->connect_error);
  }

  return $cnx;
}

 ?>
