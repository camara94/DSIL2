<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

      require_once "personne.php";

      $nom = $_GET["nom"];
      $age = $_GET["age"];

      if (ajouter($nom, $age)) {
          echo "Insertion réussit";
      } else {
          echo "Erreur lors de l'insertion";
      }

     ?>
     <br>
     <a href='personne_lister.php'>retour</a>
  </body>
</html>
