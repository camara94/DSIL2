<?php
	/*$myfile = fopen("config.ini", "r+") or die("Unable to open file!");
	$txt = "";
	while(!feof($myfile)
	{
  		$txt .= fgets($myfile) . "<br>";
	}

	fclose($myfile);*/

	function information()
	{
		$tab[]="";
		$myfile = fopen("config.ini", "r") or die("Unable to open file!");
		$server = fgets($myfile);
		$login = fgets($myfile);
		$pwd = fgets($myfile);
		$db = fgets($myfile);
		array_push($tab,explode(':', $server)[1]);
		array_push($tab,explode(':', $login)[1]);
		array_push($tab,explode(':', $pwd)[1]);
		array_push($tab,explode(':', $db)[1]);

		fclose($myfile);

		return $tab;
	}

	//information();
?>