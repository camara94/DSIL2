<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Ajouter une personne</h1>
    <form method="post" action="personne_ajouter_enregistrer.php" enctype="multipart/form-data">
      Nom : <input type="text" name="nom">
      <br>
      Age : <input type="text" name="age">
      <br>
      photo : <input type="file" name="fichier">
      <input type="submit" value="enregistrer">
      <br>
    </form>
  </body>
</html>
