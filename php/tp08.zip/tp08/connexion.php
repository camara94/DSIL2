<?php

  require_once "ini.php";
function se_connecter()
{

  $info = information();

  /*foreach ($info as $key => $value) {
   echo $value ."<br>";
  }*/

  $bd_url_serveur = trim($info[0]);
  $bd_utilisateur = trim($info[2]);
  $bd_mot_de_passe = trim($info[3]);
  $bd_nom = trim($info[4]);

//echo "*".$bd_mot_de_passe."*";
  try {
      $cnx = new PDO("mysql:host=$bd_url_serveur;dbname=$bd_nom;", $bd_utilisateur,$bd_mot_de_passe);
      // set the PDO error mode to exception
      $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      // use exec() because no results are returned
      return $cnx;
      }
  catch(PDOException $e)
      {
      echo "<br>" . $e->getMessage();
      }

  return null;
}

$cnx = se_connecter();

 ?>
