<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "personne.php";
      require_once "chargeAvecImage.php";
     ?>
  </body>
</html>
