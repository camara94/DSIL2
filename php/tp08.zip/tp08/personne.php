<?php

require_once "connexion.php";

function recuperer()
{
  $lignes = array();

  // se connecter à la base
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = "SELECT * FROM personnes";
  //echo $requette;
  $resultat = $cnx->prepare($requette);
  $resultat->execute();

  while($ligne = $resultat->fetch()) {
    $lignes[] = $ligne;
  }

  /*
  foreach($cnx->query($requette, PDO::FETCH_ASSOC) as $ligne) {
    $lignes[] = $ligne;
  }
  */
  return $lignes;
}

function ajouter($nom, $age,$file)
{
  $cnx = se_connecter();

  
  // préparation et exécution de la requête
  $requette =$cnx->prepare("INSERT INTO personnes(nom, age,nom_image) VALUES(:nom,:age,:nom_image)");
  //echo $requette;
  $requette->bindParam(":nom",$nom,PDO::PARAM_STR);
  $requette->bindParam(":age",$age,PDO::PARAM_INT);
  $requette->bindParam(":nom_image",$file,PDO::PARAM_STR);

  return $requette->execute();
}

function supprimer($id_personne)
{
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = $requette =$cnx->prepare("DELETE FROM personnes WHERE id_personne = :id ");
  $requette->bindParam(":id",$id_personne,PDO::PARAM_INT);
  //echo $requette;

  return $requette->execute();
}


function recuperer_une($id_personne)
{
  $ligne = array();

  // se connecter à la base
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = $cnx->prepare("SELECT * FROM personnes WHERE id_personne=:id");
  $requette->bindParam(':id',$id_personne,PDO::PARAM_INT);
  $requette->execute();
   
  return $requette->fetch();
}

function modifier($id, $nom, $age,$file)
{
  $cnx = se_connecter();

  // préparation et exécution de la requête
  $requette = $cnx->prepare("UPDATE personnes SET nom=:nom, age =:age, nom_image=:nom_image WHERE id_personne = :id");
  $requette->bindParam(":nom",$nom,PDO::PARAM_STR);
  $requette->bindParam(":age",$age,PDO::PARAM_INT);
  $requette->bindParam(":nom_image",$file,PDO::PARAM_STR);
  $requette->bindParam(":id",$id,PDO::PARAM_INT);
  //echo $requette;

  return $requette->execute();
}

?>
