<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "personne.php";

      $idPersonne = $_GET["id"];

      if (supprimer($idPersonne)) {
          echo "Suppression réussit";
      } else {
          echo "Erreur lors de la suppression ";
      }

     ?>
     <br>
     <a href='personne_lister.php'>retour</a>
  </body>
</html>
