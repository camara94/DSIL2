<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      require_once "personne.php";
        $id = $_POST["id"];
        $nom = $_POST["nom"];
        $age = $_POST["age"];

        $file_name = $_FILES["fichier"]["name"];
        $file_type = $_FILES["fichier"]["type"];
        $file_dest = "uploads/".$file_name;
        $extension = strrchr($file_name,".");
        $extensions_autorise = [".png",".jpg",".jpeg",".gif"];
        if(in_array($extension,$extensions_autorise))
        {
            if(move_uploaded_file($_FILES["fichier"]["tmp_name"], $file_dest))
            {
                if (modifier($id,$nom,$age,$file_dest)) 
                {
                   echo "modification réussit";
                   echo "<br><a href='personne_lister.php'>retour</a>";
                } 
                else 
                {
                  echo "Erreur lors de l'insertion";
                }
              //echo "Fichier envoyé avec succèss.";
            }
            else
            {
              echo "Erreur d'envoyer de fichier";
            }
        }
        else
        {
          echo "les extensions autorisées sont : png,jpg,gif,jpeg";
        }

      ?>
  </body>
</html>
