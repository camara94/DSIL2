<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <a href="personne_ajouter.php">ajouter</a><br>
    <a href="personne_exporter.php">exporter</a>
    <br>
    <table border="1">
      <tr>
        <th>Nom</th>
        <th>Age</th>
        <th>&nbsp;</th>
      </tr>
      <?php
        require_once "personne.php";

        $lignes = recuperer();

        if (count($lignes) == 0) {
            echo "<tr><td colspan='4'>0 résultat</td></tr>";
        } else {
          foreach ($lignes as $ligne)
          {
            echo "<tr>";
            echo "<td>" . $ligne["nom"] . "</td>";
            echo "<td>" . $ligne["age"] . "</td>";
            echo "<td><img src=\"" . $ligne["nom_image"] . "\" width=\"100\"</td>";
            echo "<td>";
            echo "<a href='personne_modifier.php?id=" . $ligne["id_personne"] . "'>modifier</a> ";
            echo "<a href='personne_supprimer.php?id=" . $ligne["id_personne"] . "'>supprimer</a>";
            echo "</td>";
            echo "</tr>";
          }
        }

       ?>
    </table>
  </body>
</html>
