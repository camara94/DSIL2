<?php
	
	require_once "personne.php";

	$txt = "";
	$donnees = recuperer();
	$myfile = fopen("personne.txt", "w") or die("Unable to open file!");
	//var_dump($donnees)
	foreach ($donnees as $key => $value) {
		$txt .= 'Nom : ' . $value['nom']. ' Prénom : '.$value['prenom'].' Age : '.$value['age'].'Année : '.$value['annee']."\n";
		
	}

	fwrite($myfile, $txt);

	fclose($myfile);
?>