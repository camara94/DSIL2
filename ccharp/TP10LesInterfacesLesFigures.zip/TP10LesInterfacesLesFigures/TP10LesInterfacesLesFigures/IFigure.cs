﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP10LesInterfacesLesFigures
{
    public interface IFigure
    {
        double perimetre();
        double surface();
    }
}
